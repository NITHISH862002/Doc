#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include"Elements\Group.cpp"
#include "XMLParser/pugixml.cpp"

namespace ConvertingFilestoVectors
{

    std::vector<std::string> order;

    int convertingFilestoVectors(std::string s, Structure &structure)
    {
        char *x = (char *)s.c_str();
        std::ifstream svgFile(x);
        std::string svgContent((std::istreambuf_iterator<char>(svgFile)), std::istreambuf_iterator<char>());

        // Parse the SVG content using PugiXML
        pugi::xml_document doc;
        pugi::xml_parse_result result = doc.load_string(svgContent.c_str());

        // Check for parsing errors
        if (result.status != pugi::xml_parse_status::status_ok)
        {
            std::cerr << "Failed to parse SVG file. Error description: " << result.description() << std::endl;
            // std::cout << "false";
            return -1;
        }

        pugi::xml_node root = doc.child("svg");

        for (pugi::xml_node node = root.first_child(); node; node = node.next_sibling())
        {
            // Serialize the individual XML element into a string
            std::stringstream tagStream;
            node.print(tagStream);

            // Get the tag as a string
            std::string tag = tagStream.str();
            if (node.name() == std::string("g"))
            {

                order.push_back(tagStream.str());
                structure.shapes.push_back(Group());
                structure.Group.push_back(tagStream.str());
            }
            else if (node.name() == std::string("rect"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Rectangle());
                structure.Reactangle.push_back(tagStream.str());
            }
            else if (node.name() == std::string("circle"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Circle());
                structure.Circle.push_back(tagStream.str());
            }
            else if (node.name() == std::string("ellipse"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Ellipse());
                structure.Ellipse.push_back(tagStream.str());
            }
            else if (node.name() == std::string("polyline"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Polyline());
                structure.Polyline.push_back(tagStream.str());
            }
            else if (node.name() == std::string("line"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Line());
                structure.Line.push_back(tagStream.str());
            }
            else if (node.name() == std::string("polygon"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Polygon());
                structure.Polygon.push_back(tagStream.str());
            }
            else if (node.name() == std::string("path"))
            {
                order.push_back(tagStream.str());
                structure.shapes.push_back(Path());
                structure.Path.push_back(tagStream.str());
            }
            else{
                order.push_back(tagStream.str());
                structure.shapes.push_back(Others());
                structure.others.push_back(tagStream.str());
            }
        }
        return 0;

    }
};
