#include <iostream>
#include "../Elements/Ellipse.cpp"
using namespace std;
#ifndef _LINE__H_
#define _LINE__H_
class Line : public Shape
{
public:
    string x1{};
    string y1{};
    string x2{};
    string y2{};
    string style{};
    string lineElement{};
    Line() : Shape("Line") {}
    Line(string input_x1, string input_y1, string input_x2, string input_y2, string input_style) : Shape("Line")
    {
        x1 = input_x1;
        x2 = input_x2;
        y1 = input_y1;
        y2 = input_y2;
        style = input_style;
        lineElement = "<line x1=\"" + x1 + "\" y1=\"" + y1 + "\" x2=\"" + x2 + "\" y2=\"" + y2 + "\"style=" + style + "\" />";
        cout << lineElement << endl;
    }
    Line(string attributes) : Shape("Line")
    {
        lineElement = "<line " + attributes + "/>";
        cout << lineElement << endl;
    }
};
#endif