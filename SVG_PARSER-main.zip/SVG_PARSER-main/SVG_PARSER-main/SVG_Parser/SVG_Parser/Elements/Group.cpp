#include <iostream>
#include "../Elements/Path.cpp"
class Group : public Shape
{
public:
    Group() : Shape("Group")
    {
    }
};
