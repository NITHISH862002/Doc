#include <iostream>
#include "../Elements/Polygon.cpp"
#ifndef __PATH__H_
#define __PATH__H_
class Path : public Shape
{
public:
   string d{};
   string lineElement{};
   Path() : Shape("Path") {}
   Path(string attributes) : Shape("Path")
   {
      lineElement = "<path " + attributes + "/>";
      cout << lineElement << endl;
   }
};
#endif