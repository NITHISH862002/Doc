#include <iostream>
#include "../Elements/Circle.cpp"
using namespace std;
#ifndef _ELLIPSE__H_
#define _ELLIPSE__H_
class Ellipse : public Shape
{

public:
    string cx{};
    string cy{};
    string rx{};
    string ry{};
    string style{};
    string ellipseElement{};
    Ellipse() : Shape("Ellipse") {}
    Ellipse(string input_cx, string input_cy, string input_rx, string input_ry, string input_style) : Shape("Ellipse")
    {
        cx = input_cx;
        cy = input_cy;
        rx = input_rx;
        ry = input_ry;
        style = input_style;

        ellipseElement = "<ellipse cx=\"" + cx + "\" cy=\"" + cy + "\" rx=" + rx + "\" ry=\"" + ry + "\"style=\"" + style + "\"/>";
        cout << ellipseElement << endl;
    }
    Ellipse(string attributes) : Shape("Ellipse")
    {
        ellipseElement = "<ellipse " + attributes + "/>";
        cout << ellipseElement << endl;
    }
};
#endif
