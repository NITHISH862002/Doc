#include <iostream>
#include <fstream>
#include <string>
#include "Menu.cpp"
#include "Creator.cpp"
#include "ConvertingFilestoVectors.cpp"
#include "DynamicFileObject.cpp"
#include "GenerateOutputFile.cpp"
#include "SvgtoJSON.cpp"
#include "SecondOptionSwitch.cpp"
using namespace std;
using namespace Menu;
using namespace ConvertingFilestoVectors;

void addNewElement(Structure &structure, Creator &creator);
void caseHandler(Structure &structure, Creator &creator, int option);

int main()
{
    auto structure = make_shared<Structure>(Structure::createStructure());
    auto creator = make_shared<Creator>(Creator::getInstance());
    GenerateOutputFile outputFile;
    bool svgCreated = false;
    bool jsonCreated = false;
    try
    {
        string name;
        cout << "Please Enter your file name like (../FOLDERNAME/FILENAME) :";
        cin >> name;
        FileName fileName(name);

        if (ConvertingFilestoVectors::convertingFilestoVectors(fileName.x, *structure) == 0)
        {
            SvgtoJson svgtojson;
            int option;
            do
            {
                Menu::displayMenu();
                cout << "Enter an Option to proceed further: ";
                cin >> option;

                switch (option)
                {
                case 1:
                {
                    int second_Option;
                    second_Option_Switch secondOption;
                    Menu::displayCountMenu();
                    cout << "Select an option to display the count of an element|elements: \n";
                    cin >> second_Option;
                    secondOption.check(second_Option, *structure);
                }
                break;
                case 2:
                    addNewElement(*structure, *creator);
                    break;
                case 3:
                {

                    string svgContent = "/* Your SVG content here */";
                    string svgFilename;
                    cout << "Enter the name for the SVG file (exception.g., MyFile.svg): ";
                    cin >> svgFilename;
                    FileName outfileName(svgFilename);
                    if (outputFile.createOutputFile((*structure), outfileName.x + ".svg"))
                    {
                        svgCreated = true;
                        svgtojson.svgtojson(outfileName.x + ".svg", outfileName.x + ".json");
                        jsonCreated = true;
                    }

                    else
                    {
                        cout << "Invalid file type option." << endl;
                    }
                    break;
                }
                default:
                    break;
                }
                if (svgCreated && jsonCreated)
                {
                    cout << "Both SVG and JSON files have been created. Exiting..." << endl;
                    break; // Exit the loop
                }
            } while (option != 4);
        }
        else
        {
            cerr << "Failed to load the file. Exiting..." << endl;
        }
    }
    catch (const exception &exception)
    {
        cerr << "An exception occurred: " << exception.what() << endl;
    }

    return 0;
}

void addNewElement(Structure &structure, Creator &creator)
{
    int third_Option;
    Menu::displayAddNewElement();
    cout << "Select an option to add a new element: \n";
    cin >> third_Option;
    caseHandler(structure, creator, third_Option);
}

void caseHandler(Structure &structure, Creator &creator, int option)
{
    if (option == 1)
    {
        int choice;
        cout << "Enter option 1 to enter attribute values:\n";
        cout << "Enter option 2 to enter the entire attribute:\n";
        cin >> choice;
        if (choice == 1)
        {
            structure.shapes.push_back(creator.createNewRectangle(structure));
        }
        else
        {
            structure.shapes.push_back(creator.createNewRectangleAsSingleAttribute(structure));
        }
    }
    else if (option == 2)
    {
        int choice{};
        cout << "Enter  option 1 to enter the values to attribute :\n";
        cout << "Enter  option 2 to enter the entire attribute :\n";
        cin >> choice;
        if (choice == 1)
        {
            (structure).shapes.push_back(creator.createNewCircle(structure));
        }
        else
        {
            (structure).shapes.push_back(creator.createNewCircleAsSingleAttribute(structure));
        }
    }
    else if (option == 3)
    {
        int choice{};
        cout << "Enter  option 1 to enter the values to attribute :\n";
        cout << "Enter  option 2 to enter the entire attribute :\n";
        cin >> choice;
        if (choice == 1)
        {
            (structure).shapes.push_back(creator.createNewEllipse(structure));
        }
        else
        {
            (structure).shapes.push_back(creator.createNewEllipseAsSingleAttribute(structure));
        }
    }
    else if (option == 4)
    {
        int choice{};
        cout << "Enter  option 1 to enter the values to attribute :\n";
        cout << "Enter  option 2 to enter the entire attribute :\n";
        cin >> choice;
        if (choice == 1)
        {
            (structure).shapes.push_back(creator.createNewLine(structure));
        }
        else
        {
            (structure).shapes.push_back(creator.createNewLineAsSingleAttribute(structure));
        }
    }
    else if (option == 5)
    {
        int choice{};
        cout << "Enter  option 1 to enter the values to attribute :\n";
        cout << "Enter  option 2 to enter the entire attribute :\n";
        cin >> choice;
        if (choice == 1)
        {
            (structure).shapes.push_back(creator.createNewPolyline(structure));
        }
        else
        {
            (structure).shapes.push_back(creator.createNewPolylineAsSingleAttribute(structure));
        }
    }
    else if (option == 6)
    {

        int choice{};
        cout << "Enter  option 1 to enter the values to attribute :\n";
        cout << "Enter  option 2 to enter the entire attribute :\n";
        cin >> choice;
        if (choice == 1)
        {
            (structure).shapes.push_back(creator.createNewPolygon(structure));
        }
        else
        {
            (structure).shapes.push_back(creator.createNewPolygonAsSingleAttribute(structure));
        }
    }
    else if (option == 7)
    {
        (structure).shapes.push_back(creator.createNewPathAsSingleAttribute(structure));
    }
    else if (option == 8)
    {
        (structure).shapes.push_back(creator.createNewtag(structure));
    }
    else
    {
        std::cout << "Invalid Option\n";
    }
}
