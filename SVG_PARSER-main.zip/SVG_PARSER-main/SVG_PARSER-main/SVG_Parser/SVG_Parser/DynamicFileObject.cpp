#include <iostream>
#include "XMLParser/pugiconfig.hpp"
#include "XMLParser/pugixml.cpp"
#include "XMLParser/pugixml.hpp"
using namespace pugi;
using namespace std;

class FileName
{
public:
    xml_document document;
    string x;
    FileName(string s)
    {
        x = s;
        if (document.load_file((char *)s.c_str()))
        {
            cout << "Your File has been Loaded.. \n";
        }
    }
};
